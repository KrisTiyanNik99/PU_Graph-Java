package fmi.model;

public class Link {
	
	private int directionPostCode; //post code of the related Node
	private float length; //path length
	
	public Link(int directionPostCode, float length) {
		super();
		this.directionPostCode = directionPostCode;
		this.length = length;
	}

	public int getDirectionPostCode() {
		return directionPostCode;
	}

	public void setDirectionPostCode(int directionPostCode) {
		this.directionPostCode = directionPostCode;
	}

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

}
