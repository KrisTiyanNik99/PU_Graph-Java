package fmi.model;

import java.util.ArrayList;

public class Node {
	
	private int postCode;
	private String name;
	private int coordX,coordY;
	private ArrayList<Link> links = new ArrayList<Link>();
	
	//logic att.
	private int parent; //post code of parent node
	private int depth = 0;
	private boolean isTested;
	
	public Node(int postCode, String name) {
		super();
		this.postCode = postCode;
		this.name = name;
	}
	
	public boolean isTested() {
		return isTested;
	}

	public void setTested(boolean isTested) {
		this.isTested = isTested;
	}

	public void addLink(Link link) {
		links.add(link);
	}

	public int getPostCode() {
		return postCode;
	}

	public void setPostCode(int postCode) {
		this.postCode = postCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCoordX() {
		return coordX;
	}

	public void setCoordX(int coordX) {
		this.coordX = coordX;
	}

	public int getCoordY() {
		return coordY;
	}

	public void setCoordY(int coordY) {
		this.coordY = coordY;
	}

	public ArrayList<Link> getLinks() {
		return links;
	}

	public void setLinks(ArrayList<Link> links) {
		this.links = links;
	}

	public int getParent() {
		return parent;
	}

	public void setParent(int parent) {
		this.parent = parent;
	}

	public int getDepth() {
		return depth;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}
	
	

}
