package fmi.model;

import java.util.HashMap;

public class Graph {
	
	private HashMap<Integer, Node> graph = new HashMap<Integer, Node>();
	
	public void addNode(Node node) {
		graph.put(node.getPostCode(), node);
	}
	
	public Node getNode(int postCode) {
		return graph.get(postCode);
	}
	
	public void addDirectionalLink(int postCodeOne, int postCodeTwo, float length) {
		graph.get(postCodeOne).addLink(new Link(postCodeTwo, length));
	}
	
	public void addBiDirectionalLink(int postCodeOne, int postCodeTwo, float length) {
		
		Node nodeOne = graph.get(postCodeOne);
		Node nodeTwo = graph.get(postCodeTwo);
		
		if(nodeOne != null && nodeTwo != null) {
			nodeOne.addLink(new Link(postCodeTwo, length));
			nodeTwo.addLink(new Link(postCodeOne, length));
		}else {
			System.out.println("Post code inccorect: " + postCodeOne + " or " + postCodeTwo);
		}
		
	}

}
