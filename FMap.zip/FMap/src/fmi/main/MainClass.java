package fmi.main;

import fmi.algorithm.BreadthFirst;
import fmi.algorithm.ISearch;
import fmi.model.Graph;
import fmi.model.Node;

public class MainClass {

	public static void main(String[] args) {
		Graph graph = new Graph();
		initGraph(graph);
		search(new BreadthFirst(graph), 1000, 9000);
		
	}
	
	public static void search(ISearch algSearch, int startCode, int goalCode) {
		
		if(algSearch.search(startCode, goalCode)) {
			System.out.println("Path if found");
		}else {
			System.out.println("There is no path");
		}
		
	}
	
	public static void initGraph(Graph graph) {
		
		graph.addNode(new Node(1000, "Sofia"));
		graph.addNode(new Node(4000, "Plovdiv"));
		graph.addNode(new Node(4400, "Pazardjik"));
		graph.addNode(new Node(8000, "Burgas"));
		graph.addNode(new Node(9000, "Varna"));
		graph.addNode(new Node(8800, "Sliven"));
		graph.addNode(new Node(5800, "Pleven"));
		graph.addNode(new Node(5000, "V.Tarnovo"));
		graph.addNode(new Node(7000, "Ruse"));
		
		graph.addBiDirectionalLink(1000, 4400, 0);
		graph.addBiDirectionalLink(1000, 5800, 0);
		graph.addBiDirectionalLink(4000, 4400, 0);
		graph.addBiDirectionalLink(4000, 5800, 0);
		graph.addBiDirectionalLink(4000, 5000, 0);
		graph.addBiDirectionalLink(4000, 8800, 0);
		graph.addBiDirectionalLink(4000, 8000, 0);
		graph.addBiDirectionalLink(8800, 8000, 0);
		graph.addBiDirectionalLink(9000, 8000, 0);
		graph.addBiDirectionalLink(9000, 7000, 0);
		graph.addBiDirectionalLink(9000, 5000, 0);
		graph.addBiDirectionalLink(5000, 7000, 0);
		graph.addBiDirectionalLink(5000, 5800, 0);
		graph.addBiDirectionalLink(7000, 8800, 0);
		
	}

}
