package fmi.algorithm;

import java.util.ArrayList;

import fmi.model.Graph;
import fmi.model.Link;
import fmi.model.Node;

public class BreadthFirst implements ISearch{

	private Graph graph;

	public BreadthFirst(Graph graph) {
		super();
		this.graph = graph;
	}

	@Override
	public boolean search(int startCode, int goalCode) {
		
		ArrayList<Integer> queue = new ArrayList<Integer>();
		queue.add(startCode);
		
		while(!queue.isEmpty()) {
			
			if(goalCode == queue.get(0)) {
				path(goalCode);
				return true;
			}
			
			Node temp = graph.getNode(queue.get(0));
			System.out.println("Current node is: " + graph.getNode(queue.get(0)).getName()
					+ ", depth: " + temp.getDepth());
			temp.setTested(true);
			queue.remove(0);
			
			for(Link link : temp.getLinks()) {
				
				Integer tempCode = link.getDirectionPostCode();
				
				if(!graph.getNode(tempCode).isTested() && !queue.contains(tempCode)) {
					queue.add(link.getDirectionPostCode());
					graph.getNode(tempCode).setDepth(temp.getDepth() + 1);
				}
				
			}
			
		}//end while
		
		return false;
	}//end search()
	
	private void path(int startCode) {
		Node temp = graph.getNode(startCode);
		System.out.println(temp.getName());
		if(temp.getDepth() == 0) return;
		Node linkedNode;
		for(Link link : temp.getLinks()) {
			linkedNode = graph.getNode(link.getDirectionPostCode());
			if(linkedNode.getDepth() == (temp.getDepth() - 1)) {
				path(linkedNode.getPostCode());
			}
			
		}
		
	}

}//end class
