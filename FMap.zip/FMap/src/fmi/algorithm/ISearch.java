package fmi.algorithm;

public interface ISearch {
	
	public boolean search(int startCode, int goalCode);

}
